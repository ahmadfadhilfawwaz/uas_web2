<html>
    <head>
        <title>Halaman Perawat</title>
    </head>
    
    <body>
        <a href="perawat.php?view=daftar_pasien">Daftar Pasien Perawatan</a> |
        <a href="perawat.php?view=daftar_obat">Daftar Obat Pasien</a> | 
        <a href="perawat.php?view=tambah_obat">Tambah Obat</a>
        
        
    </body>
    
</html>