<?php
session_start(); //memulai session
session_destroy(); //mengakhiri session
header("location:index.php");
